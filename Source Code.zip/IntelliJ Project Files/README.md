REMEMBER: Add missing dependency: ARK Tweet NLP Library: http://www.cs.cmu.edu/~ark/TweetNLP/

# README #

This is a small introduction to the project and instructions on how to run it.

### What is this repository for? ###

* TCT - Twitter Crisis Timeline
Twitter Crisis Timeline analyses the messages from a twitter dataset or a live stream and extracts emergency events that can then be plotted in a temporal or spatial representation.
This can be used for situational awareness as well as a C2C news source.

### How do I get set up? ###

Clone the repo and create a runable jar or just download the jar file and run with the following command:

>java -jar tct-text.jar inputdata.xml -> outputdata.log 2>&1 &

This runs the app and takes the inputdata.xml file as input and prints the output to a outputdata.log file, instead of writing it to a TDB.

You can also specify some parameteres for the application. 
spikeMinimum - the minimum amount of similar messages before it is consedered a spike f. ex. 15.
incrementSize defines the amount of time passed before next increment is begun f. ex. 3600 (in seconds).
relevanceMinimum - defines the amount of overlap between messsages between they are considered to be relevant to one another f ex. 0.25 (in percent of all words in the message).

>java -jar tct-text.jar inputdata.xml 15 3600 0.25 -> outputdata.log 2>&1 &

If you wish to run a live version, you need to setup our API as well. 
The API is published as another project here: https://bitbucket.org/info310and331/twittercrisistimelineapi and is also included in the archive submited with the assignment.
A website  for frontend visualization is also needed(you can use ours as a tempalte/starting point - it can be found here in the repository). 
You also need to change the URI to the endpoint in the sourcecode.
Change the line below in the main class to make it print out to the endpoint instead of a textfile and create a new jar file that you then run with the above command. 
Change it from: 
>builder.setOutputCatcher(new TextConsoleFeeder());

to: 

>builder.setOutputCatcher(new TriplestoreFeeder());

Remember to change out the tct-text.jar with the appropriate name for you jar file.


### API information ###

API can be reached at the following URL's, depending on the desired function:

General metadata(displayed in onclick overlay. Takes event Id as parameter.) Returns a JSON object with metadata.
>http://84.215.141.27:8888/event/metadata?id=1 

Fetch all events. Returns an array of JSON objects containing all events.
>http://84.215.141.27:8888/events/all

Fetch geodata for all events. Returns a stripped down geoJSON object.
>http://84.215.141.27:8888/events/geo


Fetch messages for a certain event (Takes event Id as parameter.). Returns a list of messages used to compirse a certain event as a JSON object.
>http://84.215.141.27:8888/event/messages?id=1
