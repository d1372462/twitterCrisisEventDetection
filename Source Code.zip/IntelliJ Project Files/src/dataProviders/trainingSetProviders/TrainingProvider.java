package dataProviders.trainingSetProviders;

import interfaces.TermProviderInterface;
import org.w3c.dom.NodeList;
import dataSources.XPathParser;

import java.util.LinkedList;
import java.util.List;

/**
 * Provides TrainingSets for keyword matcher & sentiment analyzer
 */
public class TrainingProvider implements TermProviderInterface {
    private XPathParser xPathParser;
    private String path;

    public TrainingProvider(String path)
    {
        this.xPathParser=new XPathParser();
        this.path=path;
    }

    /**
     * Provides positive training set for event recognition
     * @return Training Set
     */
    public List<String> provideTerms()
    {
        List<String> terms = new LinkedList<String>();
        // do xpath query to fetch positive examples:
        NodeList xpathResult = xPathParser.query("//term/text", path);
        for(int i=0; i < xpathResult.getLength();i++)
        {
            terms.add(xpathResult.item(i).getTextContent());
        }
        return terms;
    }

}
