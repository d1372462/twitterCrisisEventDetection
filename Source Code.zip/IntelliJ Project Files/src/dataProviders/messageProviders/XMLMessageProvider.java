package dataProviders.messageProviders;

import com.sun.media.sound.InvalidFormatException;
import exceptions.EmptyDataException;
import interfaces.MessageInterface;
import interfaces.MessageProviderInterface;
import models.TwitterMessage;
import org.w3c.dom.NodeList;
import dataSources.XPathParser;

import java.util.LinkedList;
import java.util.List;

/**
 * Parses Twitter Messages from xml
 */
public class XMLMessageProvider implements MessageProviderInterface {
private XPathParser xpathParser;

private String xmlPath;

public XMLMessageProvider(String xmlPath)
{
    this.xpathParser=new XPathParser();
    this.xmlPath=xmlPath;
}
/**
 * Extracts twitter messages stored in an xml file.
 * @param XML File path
 * @return List of Twitter messages
 */
    public List<MessageInterface> provideMessages() throws EmptyDataException, InvalidFormatException {
        List<MessageInterface> messages= new LinkedList<>();
        NodeList nodes = this.xpathParser.query("//Message",xmlPath);
        for(int i=0; i < nodes.getLength();i++)
        {
            TwitterMessage message = new TwitterMessage();
            String timeStamp = nodes.item(i).getAttributes().getNamedItem("timeStamp").getNodeValue();
            String text = nodes.item(i).getTextContent();
            if  ( !( text == null || text.trim().length()==0 ) && !(timeStamp == null || timeStamp.trim().length() == 0)) {
                message.setTimeStamp(Long.parseLong(timeStamp));
                message.setText(text);
                messages.add(message);
            }
        }
        return messages;
    }

}
