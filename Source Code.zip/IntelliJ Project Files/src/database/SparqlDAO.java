package database;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.apache.jena.query.*;
import org.apache.jena.rdf.model.*;
import org.apache.jena.update.*;
import interfaces.DAOInterface;
import models.Table;

/**
 * The FusekiDAO class is a data access class for performing sparql queries against a remote server.
 * NOTE: This class is not a singleton (as common for a data-access-object pattern) because it is useful
 * to be able to instantiate multiple instances of the class with different serviceURIs.
 *
 */
public class SparqlDAO implements DAOInterface{
	
	private String serviceURI;
	
	/**
	 * Constructor for FusekiDAO, takes as parameter a SPARQL endpoint
	 * @param serviceURI
	 */
	public SparqlDAO(String serviceURI)
	{
		this.serviceURI=serviceURI;
		// No logging: 
		org.apache.log4j.Logger.getRootLogger().setLevel(org.apache.log4j.Level.OFF);
        org.apache.jena.query.ARQ.init();
		//  Logging: 
		//org.apache.log4j.BasicConfigurator.configure();
	}
	
	/**
	 * Getter for prefix string
	 * (To be used for SPARQL queries)
	 * @return String of prefixes
	 */
	public String getPrefixes(){
		String prefixes="";
        prefixes+=" PREFIX :      <https://cloud.fone.no/ontologies/2017/10/22/TCTOntology#>  ";
        prefixes+=" PREFIX semo:  <http://semanticweb.cs.vu.nl/2009/11/sem/>  ";
        prefixes+=" PREFIX tct:   <https://cloud.fone.no/ontologies/2017/10/22/TCTOntology#>  ";
        prefixes+=" PREFIX owl:   <http://www.w3.org/2002/07/owl#>  ";
        prefixes+=" PREFIX gn:    <http://www.geonames.org/ontology#>  ";
        prefixes+=" PREFIX xsd:   <http://www.w3.org/2001/XMLSchema#>  ";
        prefixes+=" PREFIX rdfs:  <http://www.w3.org/2000/01/rdf-schema#> ";
        prefixes+=" PREFIX dbpedia: <https://dbpedia.org/resource/> ";
        prefixes+=" PREFIX dbo:   <http://dbpedia.org/ontology/> ";
        prefixes+=" PREFIX geo:   <http://www.w3.org/2003/01/geo/wgs84_pos#> ";
        prefixes+=" PREFIX rdf:   <http://www.w3.org/1999/02/22-rdf-syntax-ns#> ";
        prefixes+=" PREFIX moac:  <http://observedchange.com/moac/ns/#> ";
        prefixes+=" PREFIX sioctypes: <http://rdfs.org/sioc/types#> ";
        prefixes+=" PREFIX time:  <http://www.w3.org/2006/time#> ";
        prefixes+=" PREFIX sioc:  <http://rdfs.org/sioc/ns#> ";
        prefixes+=" PREFIX dc:    <http://purl.org/dc/elements/1.1/> ";
        prefixes+=" PREFIX geo: <http://www.w3.org/2003/01/geo/wgs84_pos#> ";
		return prefixes;
	}
	
	/**
	 * Does a SPARQL SELECT query to endpoint
	 * @param SPARQL SELECT query to perform (String)
	 * @param Table to store results in
	 * @return Table with results
	 */
	@Override
	public Table selectQuery(String query, Table resultTable) {
		QueryExecution q = QueryExecutionFactory.sparqlService(this.serviceURI,getPrefixes()+" "+query);
		q.setTimeout(20, TimeUnit.SECONDS);
		ResultSet queryOutput = q.execSelect();
		// loop results and gather values:
		while (queryOutput.hasNext()) {
			QuerySolution querySolution = queryOutput.nextSolution();
			HashMap<String,String> row = new HashMap<String,String>(); // create new row
			for(String column : resultTable.getTableSchema()){ // for each row in the schema of outputCollection
				if(querySolution.get(column) != null){
					if(querySolution.get(column).isLiteral())
					{
						row.put(column,querySolution.get(column).asLiteral().getValue().toString());
					}else {
						row.put(column, querySolution.get(column).toString()); // assign value to the given column of row
					}
				}else{
					row.put(column, null);
				}
			}
			resultTable.addRow(row); // add row to outputCollection
		}
		q.close();
		return resultTable;
	}


	/**
	 * Does a SPARQL UPDATE query to endpoint (insert/delete/update)
	 * @param SPARLQL update query
	 */
	@Override
	public void updateQuery(String query){	
		  UpdateRequest update = UpdateFactory.create(query);
          UpdateProcessor proc = UpdateExecutionFactory.createRemote(update, this.serviceURI);
          proc.execute();
	}
	
	/**
	 * Inserts RDF from a string to the remote triplestore
	 * @param RDF Triples as String
	 * @throws IOException
	 */
		public void insertFromString(String rdfString) throws IOException {
			// parse the file
			Model model = ModelFactory.createDefaultModel();
			model.read(new ByteArrayInputStream(rdfString.getBytes()), null, "Turtle");
			// upload the resulting model
			DatasetAccessor accessor = DatasetAccessorFactory.createHTTP(this.serviceURI);
			accessor.putModel(model);
		}
		
		/**
		 * Uploads RDF file to the remote triplestore
		 * @param RDF file (as File)
		 * @throws IOException
		 */
			public void uploadFile(File rdfFile) throws IOException {
				// parse the file
				Model model = ModelFactory.createDefaultModel();
				try (FileInputStream in = new FileInputStream(rdfFile)) {
					model.read(in, null, "RDF/XML");
				}
				// upload the resulting model
				DatasetAccessor accessor = DatasetAccessorFactory.createHTTP(this.serviceURI);
				accessor.putModel(model);
			}

}
