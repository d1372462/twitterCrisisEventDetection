package app;

import analyzers.*;
import builders.PipelineBuilder;
import com.sun.media.sound.InvalidFormatException;
import dataProviders.messageProviders.XMLMessageProvider;
import dataProviders.trainingSetProviders.TrainingProvider;
import datastores.ResultAccumulator;
import exceptions.EmptyDataException;
import exceptions.MissingBuildParamterException;
import exceptions.MissingInputException;
import helperUtils.DateTimeUtils;
import helperUtils.SortingUtils;
import interfaces.*;
import loggers.TextConsoleLogger;
import outputCatchers.TextConsoleFeeder;
import outputCatchers.TriplestoreFeeder;
import pipelineAbstractions.PipelineManager;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;

public class Main {
    private String xmlFilePath;

    /**
     * Starts pipeline with given console-arguments
     * Expects first param to be
     * @param Console arguments
     * @throws MissingInputException
     * @throws FileNotFoundException
     */
    public Main(String[] args) throws Exception {
        checkConsoleInputs(args);
        this.xmlFilePath=args[0];
        // configs:
        int incrementSize=3600*24;
        double relevanceMinimum=0.2;
        int spikeMinimum=5;
        // check for extra params:
        if ( args.length >1)
        {
            try{
                // get increment size from params:
                spikeMinimum = Integer.parseInt(args[1]);
            }catch(Exception e){}
        }
        if ( args.length >2)
        {
            try{
                // get increment size from params:
                incrementSize = Integer.parseInt(args[2]);
            }catch(Exception e){}
        }
        if ( args.length >3)
        {
            try{
                // get increment size from params:
                relevanceMinimum = Double.parseDouble(args[3]);
            }catch(Exception e){}
        }
        int clusterMiniumThreshold=2; // minimum overlap between messages to arrive in the same cluster
        // keyword lists:
        String trainingVerbs = "TrainingSets/Verbs.xml";
        String trainingNouns ="TrainingSets/Nouns.xml";
        String sentimentNegative="TrainingSets/sentiment/Negative.xml";
        String sentimentPositive="TrainingSets/sentiment/Positive.xml";
        run (   trainingVerbs, trainingNouns,
                sentimentNegative, sentimentPositive,
                incrementSize, relevanceMinimum,
                spikeMinimum, clusterMiniumThreshold );
    }

    /**
     * Checks that command-line-arguments passed are valid
     * @param Console arguments
     * @throws MissingInputException
     * @throws FileNotFoundException
     */
    private void checkConsoleInputs(String[] args) throws MissingInputException, FileNotFoundException {
        if(args.length < 1)
        {
            throw new MissingInputException("Expects 1st parameter to be path of input xml file (Optional Params: 2: Spike minimum, 3: Increment size, 4: Relevance minimum");
        }
        if(! new File(args[0]).exists())
        {
            throw new FileNotFoundException("File: "+args[0]+" not found...");
        }
    }

    /**
     * Initializes a pipeline instance with given configs, and pipes received messages through pipeline
     */
    private void run(
                     String trainingVerbs, String trainingNouns,
                     String sentimentNegative, String sentimentPositive,
                     int incrementSize, double relevanceMinimum,
                     int spikeMinimum, int clusterMiniumThreshold
                    ) throws InvalidFormatException, EmptyDataException, MissingBuildParamterException {
        System.out.println("Using File: "+xmlFilePath);
        System.out.println("Increment Size: "+(incrementSize / 3600) + " hours");
        System.out.println("Spike minimum: "+spikeMinimum+" messages");
        System.out.println("BDEM Relevance minimum: "+relevanceMinimum);
        List<MessageInterface> messages = new XMLMessageProvider(xmlFilePath).provideMessages();
        System.out.println("Loaded: "+messages.size() + " messages.");
        // sort message batch by time (needs to be ordered):
        SortingUtils.sortMessagesByTime(messages);
        // instantiate training set provider and keyword matcher
        KeywordMatcherInterface matcher = new KeywordMatcher();
        // load training terms:
        matcher.getPositiveExamples().addAll(new TrainingProvider(trainingVerbs).provideTerms());
        matcher.getPositiveExamples().addAll(new TrainingProvider(trainingNouns).provideTerms());
        // sentiment classifier:
        ClassifierInterface classifier = new NaiveBayesClassifier();
        classifier.learnTerms("negative",new TrainingProvider(sentimentNegative).provideTerms());
        classifier.learnTerms("positive",new TrainingProvider(sentimentPositive).provideTerms());

        // relevance analyzer:
        RelevanceAnalyzerInterface relevanceAnalyzer = new RelevanceAnalyzer(matcher);
        // instantiate a PipelineBuilder (builders-pattern class) to build pipeline instance:
        PipelineBuilder builder = new PipelineBuilder();
        // GIVE PARAMS TO BUILDER (ONE-BY-ONE):
        builder.setIncrementSize(incrementSize);
        builder.setRelevanceMinimum(relevanceMinimum);
        builder.setSpikeMinimum(spikeMinimum);
        builder.setEventExtractor(new EventExtractor(relevanceAnalyzer, new TagExtractor(matcher)));
        builder.setLogger(new TextConsoleLogger());
        builder.setPipeline(new Pipeline());
        builder.setRelevanceAnalyzer(relevanceAnalyzer);
        builder.setOutputCatcher(new TextConsoleFeeder());
        builder.setResultAccumulator(new ResultAccumulator(new POSClusterer(matcher)));
        builder.setClusterPartitioner(new POSClusterPartitioner(matcher,clusterMiniumThreshold));
        builder.setPlaceRecognizer(new PlaceRecognizer());
        builder.setSentimentAnalyzer(new SentimentAnalyzer(classifier));
        // build pipeline instance with builder and get instance:
        PipelineManager manager = builder.build();
        System.out.println("Output Mode: "+builder.getOutputCatcher().getLabel());
        System.out.println("Analyzing...");
        // stream messages through pipeline:
        messages.stream().forEach(message ->manager.receiveMessage(message));
        // signal to PipelineManager that we are done streaming:
        manager.endOfStream();
    }

    /**
     * Application main method .... Initiates the application
     * @param Commandline-args
     */
    public static void main (String[] args)  {
        // try to run with given params:
        try{
            new Main(args);
        }
        catch(Exception e)
        {
            // handle exceptions from Main:
            System.err.println(" !  EXCEPTION WHEN RUNNING MAIN: !");
            System.err.println("["+ DateTimeUtils.getCurrentDateTime()+"]  "+ e.getMessage());
            e.printStackTrace();
        }
    }
}
