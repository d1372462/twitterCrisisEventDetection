package loggers;

import interfaces.LoggerInterface;

public class TextConsoleLogger implements LoggerInterface
{
    @Override
    public void recieveText(String text) {
        System.out.println(text);
    }
}
