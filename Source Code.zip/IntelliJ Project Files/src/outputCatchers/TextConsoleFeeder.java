package outputCatchers;

import interfaces.OutputCatcherInterface;
import models.Event;

import java.util.List;

/**
 * Receives output events from the PipelineManager and outputs these as text to the console
 */
public class TextConsoleFeeder implements OutputCatcherInterface {
    /**
     * Receives events and prints to console
     * @param List of events to insert
     */
    @Override
    public void receiveEvents(List<Event> events)
    {
        System.out.println();
        events.stream().forEach(event -> recieveEvent(event));
    }

    /**
     * Receives a single event and prints to console
     * @param event
     */
    @Override
    public void recieveEvent(Event event) {
        System.out.println(event + System.lineSeparator()+"------------------");
    }

    /**
     * Returns human-readable label for output module
     * @return Label
     */
    @Override
    public String getLabel()
    {
        return "Console Plain Text";
    }
}
