package outputCatchers;

import database.SparqlDAO;
import helperUtils.DateTimeUtils;
import helperUtils.NumericUtils;
import helperUtils.TextUtils;
import interfaces.OutputCatcherInterface;
import models.Event;

import java.util.List;
import java.util.stream.Collectors;

/**
     * Receives output events from the PipelineManager and sends these events to the triplestore for storage.
     */
    public class TriplestoreFeeder implements OutputCatcherInterface{
        private SparqlDAO dao;
        public TriplestoreFeeder()
        {
            // instantiate new sparql dao with correct endpoint update:
            this.dao=new SparqlDAO("http://84.215.141.27:3030/TCT/update");
        }
        /**
         * Receives events and inserts to Triplestore
         * @param List of events to insert
         */
        public void receiveEvents(List<Event> events)
        {
            // build insert query:
            StringBuilder query = new StringBuilder();
            query.append(dao.getPrefixes());
            query.append("INSERT DATA ");
            query.append("{");
            events.stream().forEach(
               event-> query.append(buildQueryBody(event))
            );
            query.append("}");
            // do query:
            dao.updateQuery(query.toString());
        }

    /**
     * Builds sparql-query from single event
     * (SHOULD BE PARAMETARIZED IN THE FUTURE)
     * @param Single event to transform to partial query
     * @return
     */
    private String buildQueryBody(Event event)
        {
            // generate id for event:
            long eventId=event.hashCode();
            StringBuilder query=new StringBuilder();
            // Build query:
            // event:
            query.append(" tct:event_"+eventId+" a semo:Event , owl:NamedIndividual ; ");
            query.append(" tct:cohesionScore \"0.0\"^^xsd:double ; ");
            query.append(" tct:hasCategory   tct:Undefined ; ");
            query.append(" tct:id     "+eventId+" ; ");
            query.append(" tct:label  \""+TextUtils.stripUnsafeChars(event.getLabel())+"\" ; ");
            if ( ! (event.getCluster().getMostLikelyPlace()==null || event.getCluster().getMostLikelyPlace().getLatd() == null
            ||event.getCluster().getMostLikelyPlace().getLongd()==null ) )
            {
                query.append(" tct:lat    \""+event.getCluster().getMostLikelyPlace().getLatd()+"\"^^xsd:double ; ");
                query.append(" tct:long   \""+event.getCluster().getMostLikelyPlace().getLongd()+"\"^^xsd:double ; ");
            }
            query.append(" tct:relevance     \""+event.getRelevance()+"\"^^xsd:double ; ");
            query.append(" tct:sentiment     \"NA\" ; ");
            query.append(" tct:sentimentConfidence  \"0.0\"^^xsd:double ; ");
            query.append(" tct:start  \""+DateTimeUtils.timeStampToString(event.getTimeStamp())+"\"^^xsd:dateTime ; ");
            query.append(" tct:tags   \"");
            event.getTags().stream().forEach(
                    wordText -> query.append(wordText+",")
            );
            query.append("\" ; ");
            query.append(" tct:tweetCount    "+event.getCluster().size()+" . ");
            // events:
            event.getCluster().getResultSets().stream().forEach(
                    resultSet ->  {
            query.append("  tct:message_"+NumericUtils.generateId()+eventId+resultSet.hashCode());
            query.append(" a   tct:Tweet , owl:NamedIndividual ; ");
            query.append(" tct:hasText       \""+TextUtils.stripUnsafeChars(resultSet.getOriginMessage().getText())+"\" ; ");
            query.append(" tct:sentiment     \"NA\" ; ");
            query.append(" tct:sentimentConfidence  \"0.0\"^^xsd:double ; ");
            query.append(" tct:start  \""+ DateTimeUtils.timeStampToString(resultSet.getOriginMessage().getTimeStamp())+"\"^^xsd:dateTime ; ");
            query.append(" tct:tweetContainedIn     tct:event_"+eventId+" . ");
                    }
            );
            // dbpedia places
            event.getCluster().getDetectedPlaces().stream().forEach(
                    place ->  query.append("tct:event_"+eventId+" tct:dbPediaPlaces \""+place.getURI()+"\" . ")
            );
             return query.toString();
        }

        /**
         * Receives a single event and inserts to Triplestore
         * @param event
         */
        @Override
        public void recieveEvent(Event event) {
            // build insert query:
            StringBuilder query = new StringBuilder();
            query.append(dao.getPrefixes());
            query.append("INSERT DATA ");
            query.append("{");
            query.append(buildQueryBody(event));
            query.append("}");
            // do query:
            dao.updateQuery(query.toString());
        }

    /**
     * Returns human-readable label for output module
     * @return Label
     */
    @Override
    public String getLabel()
        {
            return "Triple-Store Insert";
        }
    }
