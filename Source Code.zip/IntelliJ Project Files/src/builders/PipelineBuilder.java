package builders;

import analyzers.EventExtractor;
import analyzers.PlaceRecognizer;
import exceptions.MissingBuildParamterException;
import interfaces.*;
import pipelineAbstractions.PipelineManager;

/**
 * Receives parameters and assembles a PipelineManager instance
 */
public class PipelineBuilder {
    private ClusterPartitionerInterface clusterPartitioner;
    private EventExtractor eventExtractor;
    private RelevanceAnalyzerInterface relevanceAnalyzer;
    private OutputCatcherInterface outputCatcher;
    private PlaceRecognizer placeRecognizer;
    private LoggerInterface logger;
    private ResultAccumulatorInterface resultAccumulator;
    private PipelineInterface pipeline;
    private SentimentAnalyzerInterface sentimentAnalyzer;
    // configs:
    private Integer incrementSize;
    private Double relevanceMinimum;
    private Integer spikeMinimum;

    /**
     * Checks that all needed parameters have been set
     * @return All received ? True/false
     */
    private boolean allParamsReceived()
    {
        return (!
                (
                 clusterPartitioner == null
                || eventExtractor == null
                || relevanceAnalyzer == null
                || outputCatcher == null
                || placeRecognizer == null
                || logger == null
                || resultAccumulator == null
                || pipeline == null
                || sentimentAnalyzer ==null
                || incrementSize == null
                || relevanceMinimum == null
                || spikeMinimum == null
                )
        );
    }
    /**
     * Builds a PipelineManager instance from previously received paramters
     * @return
     */
    public PipelineManager build() throws MissingBuildParamterException
    {
        // check all needed parameters received:
        if (! allParamsReceived())
        {
            throw new MissingBuildParamterException("PipelineBuilder is missing needed parameters");
        }
        // assemble PiplineManager instance:
        return new PipelineManager(
                    resultAccumulator,
                    outputCatcher,
                    clusterPartitioner,
                    pipeline,
                    logger,
                    eventExtractor,
                    relevanceAnalyzer,
                    placeRecognizer,
                    sentimentAnalyzer,
                    incrementSize,
                    relevanceMinimum,
                    spikeMinimum
                );
    }

    // SETTERS:
    public void setSentimentAnalyzer(SentimentAnalyzerInterface sentimentAnalyzer) {
        this.sentimentAnalyzer = sentimentAnalyzer;
    }

    public void setPipeline(PipelineInterface pipeline) {
        this.pipeline = pipeline;
    }

    public void setClusterPartitioner(ClusterPartitionerInterface clusterPartitioner) {
        this.clusterPartitioner = clusterPartitioner;
    }

    public void setEventExtractor(EventExtractor eventExtractor) {
        this.eventExtractor = eventExtractor;
    }

    public void setRelevanceAnalyzer(RelevanceAnalyzerInterface relevanceAnalyzer) {
        this.relevanceAnalyzer = relevanceAnalyzer;
    }

    public void setOutputCatcher(OutputCatcherInterface outputCatcher) {
        this.outputCatcher = outputCatcher;
    }

    public void setPlaceRecognizer(PlaceRecognizer placeRecognizer) {
        this.placeRecognizer = placeRecognizer;
    }

    public void setLogger(LoggerInterface logger) {
        this.logger = logger;
    }

    public void setResultAccumulator(ResultAccumulatorInterface resultAccumulator) {
        this.resultAccumulator = resultAccumulator;
    }

    public void setIncrementSize(Integer incrementSize) {
        this.incrementSize = incrementSize;
    }

    public void setRelevanceMinimum(Double relevanceMinimum) {
        this.relevanceMinimum = relevanceMinimum;
    }

    public void setSpikeMinimum(Integer spikeMinimum) {
        this.spikeMinimum = spikeMinimum;
    }

    // GETTERS:

    public ClusterPartitionerInterface getClusterPartitioner() {
        return clusterPartitioner;
    }

    public EventExtractor getEventExtractor() {
        return eventExtractor;
    }

    public RelevanceAnalyzerInterface getRelevanceAnalyzer() {
        return relevanceAnalyzer;
    }

    public OutputCatcherInterface getOutputCatcher() {
        return outputCatcher;
    }

    public PlaceRecognizer getPlaceRecognizer() {
        return placeRecognizer;
    }

    public LoggerInterface getLogger() {
        return logger;
    }

    public ResultAccumulatorInterface getResultAccumulator() {
        return resultAccumulator;
    }

    public PipelineInterface getPipeline() {
        return pipeline;
    }

    public SentimentAnalyzerInterface getSentimentAnalyzer() {
        return sentimentAnalyzer;
    }

    public Integer getIncrementSize() {
        return incrementSize;
    }

    public Double getRelevanceMinimum() {
        return relevanceMinimum;
    }

    public Integer getSpikeMinimum() {
        return spikeMinimum;
    }
}
