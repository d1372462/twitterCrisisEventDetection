package exceptions;

/**
 * Exception for column not found / missing
 */
public class MissingColumnException extends Exception
{

    /**
     * Constructor for MissingColumnException
     * @param Exception message
     */
    public MissingColumnException (String message)
    {
        super(message);
    }
}
