package exceptions;

/**
* Thrown when a Builder class is missing a needed parameter in order
 * to build the requested object
 */
public class MissingBuildParamterException extends Exception {
    /**
     * @param Error message
     */
    public MissingBuildParamterException(String message)
    {
        super(message);
    }
}
