package exceptions;

/**
 * Used when expected (non-nullable) data field is not present
 */
public class EmptyDataException extends Exception
{
    /**
     * @param  Error message
     */
    public EmptyDataException(String message)
    {
        super(message);
    }
}
