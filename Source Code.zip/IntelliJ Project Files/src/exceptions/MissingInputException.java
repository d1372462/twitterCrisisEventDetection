package exceptions;
/**
 * USed when expected console-arguments are not specified
 */
public class MissingInputException extends Exception {
    /**
     * @param Error message
     */
    public MissingInputException(String message)
    {
        super(message);
    }
}
