package exceptions;

/**
 * Exception for missing analysis / incomplete analysis for component.
 * Thrown if a component in the analysis-pipeline receivesa twitter message
 * that does not contain some analysis needed by this component from a previous 
 * component in the pipeline.
 * 
 * (When thrown: Indicates that a message might not have passed through the needed previous components in the
 * pipeline, or skipped some.)
 * @author user
 *
 */
public class MissingAnalysisException extends Exception{
	private static final long serialVersionUID = 6437643522698313791L;
	private String message;

  public MissingAnalysisException(String message)
  {
      super(message);
  }

}