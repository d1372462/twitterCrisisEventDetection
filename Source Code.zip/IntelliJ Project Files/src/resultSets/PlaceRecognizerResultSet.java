package resultSets;

import java.util.ArrayList;
import java.util.List;

import models.Place;

public class PlaceRecognizerResultSet {

	private List<Place> places;
	private Place mostLikelyPlace;

    public Place getMostLikelyPlace() {
        return mostLikelyPlace;
    }

    public void setMostLikelyPlace(Place mostLikelyPlace) {
        this.mostLikelyPlace = mostLikelyPlace;
    }

    public PlaceRecognizerResultSet()
	{
		places = new ArrayList<Place>();
	}
	/**
	 * @return the places
	 */
	public List<Place> getPlaces() {
		return places;
	}

	/**
	 * @param places the places to set
	 */
	public void setPlaces(List<Place> places) {
		this.places = places;
	}
	
	@Override
	public String toString()
	{
		return places.toString();
	}
}
