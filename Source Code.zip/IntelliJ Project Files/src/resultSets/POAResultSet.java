package resultSets;

import java.util.ArrayList;
import java.util.List;

import models.POSTable;
import models.Word;

public class POAResultSet {
	private POSTable posTable;
	private List < Word > analyzedWords;

	public POAResultSet() {
		this.analyzedWords = new ArrayList < Word > ();
		this.posTable = new POSTable();
	}

	/**
	 * @return the analyzedWords
	 */
	public List < Word > getAnalyzedWords() {
		return analyzedWords;
	}
	/**
	 * @param analyzedWords the analyzedWords to set
	 */
	public void setAnalyzedWords(List < Word > analyzedWords) {
		this.analyzedWords = analyzedWords;
	}


	public POSTable getPosTable() {
		return posTable;
	}

	public void setPosTable(POSTable posTable) {
		this.posTable = posTable;
	}

	public void addWord(Word word) {
		this.analyzedWords.add(word);
		if (word.getWordType() != null) {
			switch (word.getWordType().toUpperCase()) {
				case "V":
					posTable.getVerbs().add(word);
					break;
				case "N":
					posTable.getNouns().add(word);
					break;
				case "A":
					posTable.getAdjectives().add(word);
					break;
				case "^":
					posTable.getProperNouns().add(word);
			}
		}
	}

}