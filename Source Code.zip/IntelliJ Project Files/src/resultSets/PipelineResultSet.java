package resultSets;

import interfaces.MessageInterface;
import models.Event;

/**
 * This class provides a wrapper class for analysis results generated for a single message
 * when passed through the pipeline.
 * @author user
 *
 */
public class PipelineResultSet {
	private POAResultSet poaResults;
	private PlaceRecognizerResultSet placeRecognizerResults;
	private RelevanceAnalyzerResultSet relevanceResultSet;
	private MessageInterface originMessage;

	public RelevanceAnalyzerResultSet getRelevanceResultSet() {
		return relevanceResultSet;
	}

	public void setRelevanceResultSet(RelevanceAnalyzerResultSet relevanceResultSet) {
		this.relevanceResultSet = relevanceResultSet;
	}
	
	public PipelineResultSet(MessageInterface message)
	{
		this.originMessage=message;
	}
	
	/**
	 * @return the originMessage
	 */
	public MessageInterface getOriginMessage() {
		return originMessage;
	}
	/**
	 * @param originMessage the originMessage to set
	 */
	public void setOriginMessage(MessageInterface originMessage) {
		this.originMessage = originMessage;
	}
	/**
	 * @return the placeRecognizerResults
	 */
	public PlaceRecognizerResultSet getPlaceRecognizerResults() {
		return placeRecognizerResults;
	}
	/**
	 * @param placeRecognizerResults the placeRecognizerResults to set
	 */
	public void setPlaceRecognizerResults(PlaceRecognizerResultSet placeRecognizerResults) {
		this.placeRecognizerResults = placeRecognizerResults;
	}
	/**
	 * @return the poaResults
	 */
	public POAResultSet getPoaResults() {
		return poaResults;
	}
	/**
	 * @param poaResults the poaResults to set
	 */
	public void setPoaResults(POAResultSet poaResults) {
		this.poaResults = poaResults;
	}

	@Override
	public String toString()
	{
		String str="";
		if (poaResults !=null)
		{
			str += "Part-Of-Speech Results: \n"+poaResults.toString();
		}
		if(placeRecognizerResults != null)
		{
			str += "\n\nPlace Recognition Results: \n"+placeRecognizerResults.toString();
		}
		if(relevanceResultSet !=null)
        {
            str +="\n\nRelevance Results: \n"+relevanceResultSet.toString();
        }
		return str;
	}

}
