package resultSets;

import interfaces.ClassifierResultSetInterface;

/**
 * Stores the result of a (category) classification
 */
public class ClassifierResultSet implements ClassifierResultSetInterface {
    private String resultCategory;
    private double confidence;

    public String getResultCategory() {
        return resultCategory;
    }

    public void setResultCategory(String resultCategory) {
        this.resultCategory = resultCategory;
    }

    public double getConfidence() {
        return confidence;
    }

    public void setConfidence(double confidence) {
        this.confidence = confidence;
    }
}
