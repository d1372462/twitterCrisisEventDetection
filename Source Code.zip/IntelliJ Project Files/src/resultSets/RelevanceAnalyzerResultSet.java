package resultSets;

import models.Word;

import java.util.List;

public class RelevanceAnalyzerResultSet {
    private double confidence;
    private List<Word> matches;
    public double getConfidence() {
        return confidence;
    }

    public void setConfidence(double confidence) {
        this.confidence = confidence;
    }

    public List<Word> getMatches() {
        return matches;
    }

    public void setMatches(List<Word> matches) {
        this.matches = matches;
    }

    @Override
    public String toString()
    {
       return "Relevance Score: "+getConfidence()+" Match count: "+getMatches().size()+" \nMatches: "+getMatches();
    }
}
