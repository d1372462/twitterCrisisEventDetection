package analyzers;

import interfaces.ClustererInterface;
import interfaces.KeywordMatcherInterface;
import models.Cluster;
import models.Word;
import resultSets.PipelineResultSet;

import javax.swing.text.html.HTMLDocument;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * Clusters PipeLineResultSets into buckets of resultsets with cohesive properties
 */
public class POSClusterer implements ClustererInterface{
    private KeywordMatcherInterface keywordMatcher;
    public POSClusterer(KeywordMatcherInterface keywordMatcher)
    {
        this.keywordMatcher=keywordMatcher;
    }

    /**
     * Receives a list of pipeline resultsets ordered by POA overlap, and a new PipelineResultSet to insert,
     *
     * and inserts the new resultset after the element with the highest match to the new resultset
     * @param poaSortedList
     * @param resultSet
     * @return
     */
    @Override
    public List<PipelineResultSet> insertToOrderedCollection(List<PipelineResultSet> poaSortedList, PipelineResultSet resultSet) {
        // if list is empty, add as first element (no need to find appropriate insertion point):
        if(poaSortedList.size() < 1)
        {
            poaSortedList.add(resultSet);
            return poaSortedList;
        }
        // find appropriate insertion point:
        PipelineResultSet bestMatch = poaSortedList.get(0);
        int bestMatchCount=0;
        int insertionIndex=0;
        int currentIndex=0;
        for(PipelineResultSet set : poaSortedList)
        {
            // measure pos overlap:
            int currentMatch=keywordMatcher.matchPOA(resultSet.getPoaResults(),set.getPoaResults()).size();
            // check if better match than bestMatch found so far:
            if ( currentMatch > bestMatchCount)
            {
                bestMatch=set;
                bestMatchCount=currentMatch;
                insertionIndex=currentIndex;
            }
            // increment current index:
            currentIndex++;
        }
        // insert element at appropriate index:
        if(insertionIndex > poaSortedList.size()-1)
        {
            poaSortedList.add(resultSet);
        }else {
            poaSortedList.add(insertionIndex, resultSet);
        }
        return poaSortedList;
    }

    }
