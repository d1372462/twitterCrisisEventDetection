package analyzers;

import interfaces.KeywordMatcherInterface;
import interfaces.TagExtractorInterface;
import models.Cluster;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Class to generate tags from action-words (verbs)
 */
public class TagExtractor implements TagExtractorInterface {
private KeywordMatcherInterface keywordMatcher;

    /**
     * @param KeywordMatcher instance
     */
    public TagExtractor(KeywordMatcherInterface keywordMatcher)
    {
    this.keywordMatcher=keywordMatcher;
    }

    /**
     * Recieves a cluster and generates a list of action-word tags from overlap with BDEM terms
     * @param Cluster to generate for
     * @return List of distinct tags
     */
    public List<String> extractTags(Cluster cluster)
    {
       return keywordMatcher.matchPositive(cluster.getAccumulatedPOS())
               .stream()
               .map(word->word.getText().toLowerCase())
               .distinct()
               .collect(Collectors.toList());
    }
}
