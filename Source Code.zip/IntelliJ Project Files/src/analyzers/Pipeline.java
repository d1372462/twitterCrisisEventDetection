package analyzers;

import dataProviders.trainingSetProviders.TrainingProvider;
import datastores.ResultAccumulator;
import interfaces.MessageInterface;
import interfaces.PipelineInterface;
import interfaces.ResultAccumulatorInterface;
import resultSets.*;

/**
 * Does event recognition over a single message
 * This class is a singleton such that the state is preserved throughout the runtime of the application,
 * and to ensure that only a single instance exists (to avoid re-loading training sets etc... multiple times)
 */
public class Pipeline implements PipelineInterface{
    private EventMemberQualifier eventMemberQualifier;
    public Pipeline()
    {
        this.eventMemberQualifier = new EventMemberQualifier();
    }

    /**
     * Runs a single twitter message through the pipeline
     * (Does a limited amount of work due to clustering being handled by other
     * classes. Thus it only handles what happens to single tweets. Clusters are handled elsewhere.
     * @param message
     */
    public boolean pipeThrough(MessageInterface message, ResultAccumulatorInterface accumulator)
    {
        // create new pipeline resultset for this message:
        PipelineResultSet resultSet = new PipelineResultSet(message);
	    /*
		*  ##### EVENT-RECOGNITION PIPELINE: #####
		*/
        // 1. part of speech analysis:
        POAResultSet poaResults = PartOfSpeechAnalyzer.getInstance().analyze(message);
        // if not qualified (does not contain verb+proper noun), discard message and terminate
        if(! eventMemberQualifier.qualifyMessage(poaResults))
        {
            return false;
        }
		/*
		* ##### POST-PIPELINE STEPS: #####
		*/
        // add results to result set:
        resultSet.setPoaResults(poaResults);
        // accumulate result:
        accumulator.accumulate(resultSet);
        return true;
    }
}