package analyzers;

import helperUtils.TextUtils;
import interfaces.EventExtractorInterface;
import interfaces.KeywordMatcherInterface;
import interfaces.RelevanceAnalyzerInterface;
import interfaces.TagExtractorInterface;
import models.Cluster;
import models.Event;
import models.Word;
import resultSets.PipelineResultSet;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

/**
 * Extracts an event from a given cluster
 * (Presumes that the cluster constitutes an event (from RelevanceAnalyzer))
 */
public class EventExtractor implements EventExtractorInterface {


    private RelevanceAnalyzerInterface relevanceAnalyzer;
    private TagExtractorInterface tagExtractor;

    public EventExtractor(RelevanceAnalyzerInterface relevanceAnalyzer, TagExtractorInterface tagExtractor)
    {
        this.relevanceAnalyzer=relevanceAnalyzer;
        this.tagExtractor=tagExtractor;
    }

    /**
     * Receives a cluster (of messages) as input and generates an event object from the cluster data
     * @param Cluster
     * @return Derived event object
     */
    public Event extractEvent(Cluster cluster)
    {
        // find most common noun:
        Word noun=TextUtils.findMostCommonWord(cluster.getAccumulatedPOS().getNouns());
        // find most common verb:
        Word actionWord = TextUtils.findMostCommonWord(cluster.getAccumulatedPOS().getVerbs());
        // find most common proper noun:
        Word namedEntity =  TextUtils.findMostCommonWord(cluster.getAccumulatedPOS().getProperNouns());
        // check words found, else default to nothing:
        if (noun == null)
        {
            noun = new Word("");
        }
        if(actionWord == null)
        {
            actionWord = new Word("");
        }
        if(namedEntity == null)
        {
            namedEntity = new Word("");
        }
        // create event:
        Event event = new Event();
        // generate label from actionword + named entity:
        event.setLabel(TextUtils.toFirstUpper(noun.getText())+" , "+actionWord.getText() + " : "+TextUtils.toFirstUpper(namedEntity.getText()));
        // get relevance (to BDEM):
        event.setRelevance(relevanceAnalyzer.analyze(cluster).getConfidence());
        // generate uri:
        event.setURI(actionWord.getText()+namedEntity.getText());
        // set cluster:
        event.setCluster(cluster);
        // set sentiment:
        event.setSentiment(cluster.getSentiment());
        // set sentiment confidence:
        event.setSentimentCondifdence(cluster.getSentimentCondifdence());
        // extract start timeStamp:
        long min=cluster.getResultSets().get(0).getOriginMessage().getTimeStamp();
        for (PipelineResultSet res : cluster.getResultSets())
        {
            if (res.getOriginMessage().getTimeStamp() < min){
                min = res.getOriginMessage().getTimeStamp();
            }
        }
        event.setTimeStamp(min);
        // extract tags:
        event.setTags(tagExtractor.extractTags(cluster));
        return event;
    }

    /**
     * Recieves a list of clusters and extracts an event from each cluster
     * @param List of clusters
     * @return List of events
     */
    public List<Event> extractEvents(List<Cluster> clusters)
    {
      return clusters.stream()
                .map(cluster -> extractEvent(cluster))
                .collect(Collectors.toCollection(LinkedList::new));
    }
}
