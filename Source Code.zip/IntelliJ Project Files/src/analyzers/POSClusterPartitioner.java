package analyzers;

import interfaces.ClusterPartitionerInterface;
import interfaces.KeywordMatcherInterface;
import models.Cluster;
import resultSets.PipelineResultSet;

import java.util.LinkedList;
import java.util.List;

/**
 * Partitions an ordered collection of resultsets into clusters
 */
public class POSClusterPartitioner implements ClusterPartitionerInterface {
    private int clusterMinThresh;
    private KeywordMatcherInterface keywordMatcher;
    public POSClusterPartitioner(KeywordMatcherInterface keywordMatcher, int clusterMinThresh)
    {
        this.clusterMinThresh=clusterMinThresh;
        this.keywordMatcher=keywordMatcher;
    }
    /**
     * Receives an ordered list of pipeline resultsets according to POS overlap,
     * and partitions the list into clusters of pipeline results based on POS overlap > minimum
     * @param Ordered list of pipeline-result sets
     * @return List of clusters
     */
    public List<Cluster> partitionOrderedList(LinkedList<PipelineResultSet> orderedList)
    {
        List<Cluster> result = new LinkedList<Cluster>();
        // empty ordred llist = empty cluster list back:
        if (orderedList.size()<1)
        {
            return result;
        }
        Cluster cluster = new Cluster();
        PipelineResultSet prev = orderedList.getFirst();
        for(PipelineResultSet current : orderedList)
        {
            if ( keywordMatcher.matchPOA(prev.getPoaResults(), current.getPoaResults()).size() < clusterMinThresh )
            {
                // store cluster in output:
                result.add(cluster);
                // create new cluster to store next messages:
                cluster = new Cluster();
            }
            cluster.add(current);
            prev=current;
        }
        result.add(cluster);
        return result;
    }
}
