package analyzers;

import java.util.List;

import analyzers.external.de.daslaboratorium.machinelearning.classifier.Classification;
import analyzers.external.de.daslaboratorium.machinelearning.classifier.Classifier;
import analyzers.external.de.daslaboratorium.machinelearning.classifier.bayes.BayesClassifier;
import interfaces.ClassifierInterface;
import interfaces.ClassifierResultSetInterface;

/**
 * Classifies a message using Naive Bayes algorithm
 **/
public class NaiveBayesClassifier implements ClassifierInterface {
	/*
     * Create a new classifier instance. The context features are
     * Strings and the context will be classified with a String according
     * to the featureset of the context.
     */
	final Classifier < String, String > bayes = new BayesClassifier < String, String > ();
	/**
	 * Constructor for naive bayes classifier.  Takes as parameter a list of positive and a
	 * list of negative training examples (both lists of strings)
	 * @param Positive training examples
	 * @param Negative training examples
	 **/
	public NaiveBayesClassifier() {
		bayes.setMemoryCapacity(500000000); // remember the last 5 000 000 learned classifications
	}

	public void learnTerms(String category, List < String > terms) {
		bayes.learn(category, terms);
	}

	/**
	 * Classifies a given list of terms and stores in a resultset the resulting category and confidence
	 * @param Terms to classify on
	 * @param resultSet
	 * @return
	 */
	public ClassifierResultSetInterface classify(List < String > terms, ClassifierResultSetInterface resultSet) {
		// classify terms:
		Classification < String, String > bayesClassification = bayes.classify(terms);
		// extract most likely category:
		resultSet.setResultCategory(bayesClassification.getCategory());
		// etract confidence:
		resultSet.setConfidence(bayesClassification.getProbability());
		// classify message and return:
		return resultSet;
	}
}