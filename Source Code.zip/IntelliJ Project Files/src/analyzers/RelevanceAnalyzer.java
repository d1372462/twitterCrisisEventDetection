package analyzers;

import interfaces.KeywordMatcherInterface;
import interfaces.RelevanceAnalyzerInterface;
import models.Cluster;
import models.POSTable;
import models.Word;
import resultSets.POAResultSet;
import resultSets.RelevanceAnalyzerResultSet;

import java.util.List;

/**
 * Determines the relevance of a detected event in relation to emergency management
 */
public class RelevanceAnalyzer implements RelevanceAnalyzerInterface {
private KeywordMatcherInterface keywordMatcher;
public RelevanceAnalyzer(KeywordMatcherInterface keywordMatcher)
{
    this.keywordMatcher=keywordMatcher;
}
    /**
     * Estimates the relevance of a cluster of messages (to BDEM)
     * (overloaded proxy method for analyze(POSTable ....))
     * @param Cluster of messages
     * @return Resultset from relevance analysis
     */
    public RelevanceAnalyzerResultSet analyze(Cluster cluster)
    {
       return analyze(cluster.getAccumulatedPOS());
    }

    /**
     * Estimates the relevancy to emergency of a given POAResultSet from a message
     * @param poaResultSet
     * @return RelevanceAnalyzerResultSet with matches and confidence (decimal)
     */
    public RelevanceAnalyzerResultSet analyze(POSTable posTable)
    {
        RelevanceAnalyzerResultSet resultSet = new RelevanceAnalyzerResultSet();
        // determine keyword matches:
        List<Word> matches= keywordMatcher.matchPositive(posTable);
        resultSet.setMatches(matches);
        // (confidence = fraction of matches relative to total amount of words)
        resultSet.setConfidence((double)matches.size() / (double)posTable.getSize());
        return resultSet;
    }
}
