package analyzers;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import analyzers.external.cmu.arktweetnlp.RunTagger;
import interfaces.MessageInterface;
import resultSets.POAResultSet;

/**
 * Adapter Singleton (Due to performance.... ensure tagger only instansiated once, run many times)
 * for RunTagger to bridge between event recognizer pipeline and TwitterNLP RunTagger
 * Acts as a facade for RunTagger towards EventRecognizer
 * @author user
 *
 */
public class PartOfSpeechAnalyzer{

	private static PartOfSpeechAnalyzer instance;
	private RunTagger tagger;

	private PartOfSpeechAnalyzer()
    {
        try {
            this.tagger=new RunTagger();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

	/**
	 * Getter for singleton instance
	 * @return PartOfSpeechAnalyzer instance
	 */
	public static PartOfSpeechAnalyzer getInstance()
	{
		if(instance==null)
		{
			instance=new PartOfSpeechAnalyzer();
		}
		return instance;
	}
	/**
	 * Takes a twitter message as input and does PartOfSpeech analysis
	 * (needs to set output variables instead of printing result as text!! (NOT COMPLETE) )
	 * @param message
	 */
	public POAResultSet analyze(MessageInterface message)
	{
        try {
           return tagger.runTagger(message);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            System.err.println("Error while running POS analysis: ");
            e.printStackTrace();
        }
        return null;
    }
	

}
