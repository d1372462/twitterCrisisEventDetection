package analyzers;

import interfaces.KeywordMatcherInterface;
import models.POSTable;
import models.Word;
import resultSets.EventClassifyerResultSet;
import resultSets.POAResultSet;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

public class KeywordMatcher implements KeywordMatcherInterface {

    private List<String> positiveExamples;


    public KeywordMatcher()
    {
        this.positiveExamples=new LinkedList<>();
    }

    public void setPositiveExamples(List<String> positiveExamples) {
        this.positiveExamples = positiveExamples;
    }

    /**
     * Counts the overlap between verbs and nouns in the given POSTable and positive
     * terms loaded previously
     * @param PosTable to match
     * @return List of matching words between input poa and positive examples
     */
    public List<Word> matchPositive(POSTable posTable)
    {
        return posTable.getAll().stream()
                .filter( w -> w.getWordType().toUpperCase().equals("V") || w.getWordType().toUpperCase().equals("N"))
                .filter(w -> positiveExamples.contains(w.toString().toLowerCase()))
                .collect(Collectors.toCollection(LinkedList::new));
    }

    /**
     * Counts the overlap between verbs and nouns in the given POAResultSet and positive
     * terms loaded previously
     * @param poaResultSet
     * @return List of matching words between input poa and positive examples
     */
    public List<Word> matchPositive(POAResultSet poaResultSet)
    {
         return poaResultSet.getAnalyzedWords().stream()
                    .filter( w -> w.getWordType().toUpperCase().equals("V") || w.getWordType().toUpperCase().equals("N"))
                    .filter(w -> positiveExamples.contains(w.toString().toLowerCase()))
                    .collect(Collectors.toCollection(LinkedList::new));
    }

    /**
     * Measures the overlap of two POA results
     * @param poa1
     * @param poa2
     * @return List of matching verbs and proper nouns between the two poa results
     */
    public List<Word> matchPOA(POAResultSet poa1, POAResultSet poa2)
    {
        return poa1.getAnalyzedWords().stream()
                .filter(w -> poa2.getAnalyzedWords().contains(w))
                .filter(w -> w.getWordType().toUpperCase().equals("V") || w.getWordType().toUpperCase().equals("^"))
                .collect(Collectors.toCollection(LinkedList::new));
    }

    // GETTERS & SETTERS:
    public List<String> getPositiveExamples() {
        return positiveExamples;
    }

}
