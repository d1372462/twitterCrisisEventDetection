package analyzers;

import java.util.stream.Collectors;

import interfaces.*;
import models.Cluster;

/**
 * Does sentiment analysis over a collection of messages
 */
public class SentimentAnalyzer  implements SentimentAnalyzerInterface{
    private double numericResult;
    private ClassifierInterface classifier;

    public SentimentAnalyzer(ClassifierInterface classifier)
    {
        this.classifier=classifier;
    }

	/**
	 * Recieves a cluster and a resultset to store result in, then does sentiment classification
	 * on cluster.
	 * @param cluster
	 * @param resultSet
	 * @return Sentiment resultset
	 */
	public ClassifierResultSetInterface analyze(Cluster cluster, ClassifierResultSetInterface resultSet) {
		 classifier.classify(cluster.getAccumulatedPOS().getVerbs().stream().map(word -> word.getText()).collect(Collectors.toList()), resultSet);
		 return resultSet;
	}
	
	public double getNumericResult()
	{
		return numericResult;
	}

}
