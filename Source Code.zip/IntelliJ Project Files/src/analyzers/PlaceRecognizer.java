package analyzers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

import database.SparqlDAO;
import exceptions.MissingAnalysisException;
import helperUtils.TextUtils;
import interfaces.MessageInterface;
import interfaces.PlaceRecognizerInterface;
import models.*;
import resultSets.POAResultSet;
import resultSets.PlaceRecognizerResultSet;

public class PlaceRecognizer implements PlaceRecognizerInterface {
	/**
	 * Takes a twitter message and part of speech analysis results belonning to the message as input and does ontology-supported place recognition by DBpedia queries
	 * Requires that part-of-speech-analysis is already complete on message
	 * @param message
	 * @throws MissingAnalysisException 
	 */
	public PlaceRecognizerResultSet analyze(Cluster cluster)
	{
		PlaceRecognizerResultSet resultSet = new PlaceRecognizerResultSet();

		// build sparql query from unknown words:
		List<Word> potentialPlaces = cluster.getAccumulatedPOS().getProperNouns();
        if ( potentialPlaces.size() < 1 )
        {
            return resultSet;
        }
		StringBuilder query = new StringBuilder();
		query.append(
		  " SELECT DISTINCT ?s ?lat ?long "
		  + " WHERE  { "
		  + "{");
		boolean isFirst=true;
		for(Word word : potentialPlaces)
		{
			if(! isFirst)
			{
				query.append(" UNION { ");
			}else{
				isFirst=false;
			}
			query.append(" ?s a dbo:Place . ?s geo:lat ?lat .  ?s geo:long ?long . ?s rdfs:label ?label . ?s rdfs:label \""+ TextUtils.toFirstUpper(word.getText()) +"\"@en . ");
			query.append(" } ");
		}
		
		query.append(" } LIMIT "+potentialPlaces.size());
		
		// RUN SELECT QUERY:
		SparqlDAO dao = new SparqlDAO("http://dbpedia.org/sparql");
		Table result = new Table(new String[]{"s","lat","long"});
		dao.selectQuery(dao.getPrefixes() + query.toString(), result);
		 // convert result rows to places:
		for(HashMap<String,String> row : result.getRows())
		{
		 Place p = new Place();
		 p.setURI(row.get("s"));
		 p.setLatd(row.get("lat"));
		 p.setLongd(row.get("long"));
		 // add event to message event places:
		resultSet.getPlaces().add(p);
		}
		// find most likely place:
		HashMap<String,Place> placeMap = new HashMap<>();
		// put each place as uri, place:
		resultSet.getPlaces().stream().forEach( place ->
			placeMap.put(place.getURI(),place)
		);
		// find most likely:
		if(placeMap.size()>0)
		{
			resultSet.setMostLikelyPlace(
					// fetch place object from hashmap by uri:
					placeMap.get(
							// map to list of words and pass to findMostCommonWord...
							TextUtils.findMostCommonWord(placeMap.keySet().stream()
									.map(placeUri -> new Word(placeUri))
									.collect(Collectors.toCollection(LinkedList::new))).getText()
					)
			);
		}

		return resultSet;
	}
	
}
