package analyzers;

import interfaces.EventQualifierInterface;
import models.Word;
import resultSets.POAResultSet;

import java.util.LinkedList;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class EventMemberQualifier implements EventQualifierInterface {

    /**
     * Receives a POAResultSet beloning to a given message, and determines if the given message is (micro) event
     * @param poaResultSet
     * @return Qualified, True/False
     */
    public boolean qualifyMessage(POAResultSet poaResultSet)
    {
        return (poaResultSet.getPosTable().getVerbs().size() >0 && poaResultSet.getPosTable().getProperNouns().size()>0);
    }

}
