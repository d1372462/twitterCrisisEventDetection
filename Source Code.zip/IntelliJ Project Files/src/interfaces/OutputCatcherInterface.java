package interfaces;

import models.Event;

import java.util.List;

/**
 * Implemented by any class that can receive output from the pipeline (event objects)
 * and store or output them in some way. Generic pipeline output-handlers.
 */
public interface OutputCatcherInterface {
    /**
     * Receives a list of events to catch
     * @param List of events
     */
    public void receiveEvents(List<Event> events);

    /**
     * Recisves a single event to catch
     * @param event
     */
    public void recieveEvent(Event event);

    /**
     * Human readable label to use for logging
     * @return label
     */
    public String getLabel();
}
