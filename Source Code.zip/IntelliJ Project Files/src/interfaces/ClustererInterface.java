package interfaces;

import resultSets.PipelineResultSet;
import java.util.List;

public interface ClustererInterface {
    /**
     * Receives a list of pipeline resultsets ordered by some attribute (ex: POS Overlap),
     * and a PipelineResultSet to insert into this collection
     *
     * and inserts the new resultset after the element with the highest match to the new resultset
     * @param Ordered list of PipelineResultsets to insert into
     * @param PipelineResultSet to insert
     * @return List with new resultset inserted at correct location
     */
    public List<PipelineResultSet> insertToOrderedCollection(List<PipelineResultSet> list, PipelineResultSet resultSet);
}
