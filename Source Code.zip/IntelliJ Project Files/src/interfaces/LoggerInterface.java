package interfaces;

/**
 * Implemented by a logger class that can handle logging
 */
public interface LoggerInterface {

    /**
     * Receives text to log as a log entry...
     * @param text
     */
    public void recieveText(String text);
}
