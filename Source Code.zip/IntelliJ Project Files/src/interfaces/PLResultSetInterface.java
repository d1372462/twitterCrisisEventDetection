package interfaces;

public interface PLResultSetInterface {

	
	
}
