package interfaces;

import models.Cluster;

import java.util.List;

public interface TagExtractorInterface {
    public List<String> extractTags(Cluster cluster);
}
