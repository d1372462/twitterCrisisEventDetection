package interfaces;

import java.util.List;

public interface ClassifierInterface {
    public ClassifierResultSetInterface classify(List<String> terms, ClassifierResultSetInterface resultSet);
    public void learnTerms(String category, List<String> terms);
}
