package interfaces;

import resultSets.POAResultSet;

public interface EventQualifierInterface {
    /**
     * Receives a POAResultSet beloning to a given message,
     * and determines if the given message is qualified to be included for analysis (pre-processing)
     * @param poaResultSet
     * @return Qualified, True/False
     */
    public boolean qualifyMessage(POAResultSet poaResultSet);

}
