package interfaces;

import models.Cluster;
import models.POSTable;
import resultSets.RelevanceAnalyzerResultSet;

public interface RelevanceAnalyzerInterface {

    /**
     * Estimates the relevance of a cluster of messages (to BDEM)
     * (overloaded proxy method for analyze(POSTable ....))
     * @param Cluster of messages
     * @return Resultset from relevance analysis
     */
    public RelevanceAnalyzerResultSet analyze(Cluster cluster);

    /**
     * Estimates the relevancy to emergency of a given POAResultSet from a message
     * @param poaResultSet
     * @return RelevanceAnalyzerResultSet with matches and confidence (decimal)
     */
    public RelevanceAnalyzerResultSet analyze(POSTable posTable);
}
