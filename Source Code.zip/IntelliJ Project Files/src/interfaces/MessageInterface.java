package interfaces;

import java.util.HashMap;
import java.util.List;

import models.Event;
import models.Word;

/**
 * Interface for general message 
 * Implemented by specific message (ex: TwittermEssage)
 */
public interface MessageInterface {
	
	/**
	 * Getter for message text
	 * @return Message text
	 */
	public String getText();
	
	/**
	 * Setter for message text
	 * @param Text to set
	 */
	public void setText (String text);

	public long getTimeStamp();

	public void setTimeStamp(long timeStamp);
	
}
