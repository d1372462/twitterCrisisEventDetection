package interfaces;

import models.Cluster;
import resultSets.PipelineResultSet;

import java.util.LinkedList;
import java.util.List;

public interface ClusterPartitionerInterface {
    /**
     * Partitions an ordered list of resultsets into clusters
     * @param resultSets
     * @return
     */
    public List<Cluster> partitionOrderedList(LinkedList<PipelineResultSet> resultSets);
}
