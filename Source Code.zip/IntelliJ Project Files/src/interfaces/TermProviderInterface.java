package interfaces;

public interface TermProviderInterface {
}
