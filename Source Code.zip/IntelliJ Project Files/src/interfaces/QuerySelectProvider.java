package interfaces;

public interface QuerySelectProvider {



}
