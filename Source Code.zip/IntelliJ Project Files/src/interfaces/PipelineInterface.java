package interfaces;

public interface PipelineInterface {

    public boolean pipeThrough(MessageInterface message, ResultAccumulatorInterface accumulator);
}
