package interfaces;

import models.Cluster;
import models.Event;

import java.util.List;

public interface EventExtractorInterface {

    /**
     * Receives a cluster (of messages) as input and generates an event object from the cluster data
     * @param Cluster
     * @return Derived event object
     */
    public Event extractEvent(Cluster cluster);

    /**
     * Recieves a list of clusters and extracts an event from each cluster
     * @param List of clusters
     * @return List of events
     */
    public List<Event> extractEvents(List<Cluster> clusters);
}
