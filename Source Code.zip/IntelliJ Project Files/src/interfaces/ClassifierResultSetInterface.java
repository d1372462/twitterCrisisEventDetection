package interfaces;

public interface ClassifierResultSetInterface {
    public String getResultCategory();
    public double getConfidence();
    public void setConfidence(double confidence);
    public void setResultCategory(String resultCategory);
}
