package interfaces;
import java.util.List;

/**
 * Implemented by a MessageProvider that can provide messages from (any) source (ex: DB, file, API calls etc...)
 */
public interface MessageProviderInterface {

    /**
     * Reads and returns a list of messages from the given source
     * @return List of messages
     * @throws Exception if fails to fetch messages
     */
    public List<MessageInterface> provideMessages() throws Exception;

}
