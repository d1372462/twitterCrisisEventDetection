package interfaces;

import resultSets.PipelineResultSet;

public interface OutputGenerator {

	/**
	 * Takes a pipeline resultset as input and generates 
	 * string output from resultset
	 * @param Resultset to generate outoput for
	 * @return String output from resultset
	 */
	public String generate(PipelineResultSet resultSet);
}
