package interfaces;

import resultSets.PipelineResultSet;

import java.util.LinkedList;
public interface ResultAccumulatorInterface {

    public void accumulate(PipelineResultSet resultSet);

    public LinkedList<PipelineResultSet> getOrderedResultSets();

    public void reset();

}
