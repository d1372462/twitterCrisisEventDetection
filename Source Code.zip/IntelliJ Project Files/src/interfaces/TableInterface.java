package interfaces;

import java.util.HashMap;
import java.util.List;

/**
 * Interface for general table
 * (To be used for DB query results etc...)
 * @author user
 *
 */
public interface TableInterface {
	
	/**
	 * Adds a row to db in the form of HashMap<String,String>
	 * @param Row to add
	 */
	public void addRow(HashMap<String,String> row);
	
	/**
	 * Getter for rows in table
	 * @return List of rows in table
	 */
	public List<HashMap<String,String>> getRows();
	
	/**
	 * Adds a row to db in the form of String[]
	 * @param Row to add
	 */
	public void addRow(String[] row);
	
	/**
	 * Removes a row at given index
	 * @param rowIndex
	 */
	public void removeRow(int rowIndex);
	
	/**
	 * Getter for specific row
	 * @param Row index to get
	 * @return  Row at given index
	 */
	public HashMap<String,String> getRow(int rowIndex);
	
	/**
	 * Getter for table schema
	 * @return Schema string array
	 */
	public String[] getTableSchema();
	
}
