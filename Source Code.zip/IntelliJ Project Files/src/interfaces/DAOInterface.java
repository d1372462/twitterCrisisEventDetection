package interfaces;

import java.util.List;

import models.Table;

/**
 * Interface for general DAO class. (Implemented by FusekiDAO)
 * @author user
 *
 */
public interface DAOInterface {
	
	/**
	 * Does a select query to DB and returns 
	 * a results table (implementing TableInterface)
	 * @param SELECT query to perform
	 * @param Result table to store results in
	 * @return Result table
	 */
	public TableInterface selectQuery(String query, Table resultTable);
	
	/**
	 * Does an UPDATE query to DB (no return)
	 * @param UPDATE query to perform
	 */
	public void updateQuery(String query);
	
}
