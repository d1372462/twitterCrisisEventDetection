package interfaces;

import exceptions.MissingAnalysisException;
import models.Cluster;
import resultSets.PlaceRecognizerResultSet;

public interface PlaceRecognizerInterface {
    /**
     * Takes a twitter message and part of speech analysis results belonning to the message as input and does ontology-supported place recognition by DBpedia queries
     * Requires that part-of-speech-analysis is already complete on message
     * @param message
     * @throws MissingAnalysisException
     */
    public PlaceRecognizerResultSet analyze(Cluster cluster);


}
