package interfaces;

import models.Cluster;

public interface SentimentAnalyzerInterface {
    public ClassifierResultSetInterface analyze(Cluster cluster, ClassifierResultSetInterface resultSet);
    }
