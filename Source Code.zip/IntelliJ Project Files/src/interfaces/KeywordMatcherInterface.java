package interfaces;

import models.POSTable;
import models.Word;
import resultSets.POAResultSet;

import java.util.List;

public interface KeywordMatcherInterface {

    public void setPositiveExamples(List<String> positiveExamples);
    public List<Word> matchPositive(POSTable posTable);
    public List<Word> matchPositive(POAResultSet poaResultSet);
    public List<Word> matchPOA(POAResultSet poa1, POAResultSet poa2);
    public List<String> getPositiveExamples();
}
