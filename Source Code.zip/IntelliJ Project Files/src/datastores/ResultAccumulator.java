package datastores;

import analyzers.POSClusterer;
import com.sun.xml.internal.bind.annotation.OverrideAnnotationOf;
import interfaces.ClustererInterface;
import interfaces.ResultAccumulatorInterface;
import resultSets.PipelineResultSet;

import java.util.LinkedList;

/**
 * Holds an in-memory representation of the analysis results generated thus far by pipeline output
 * during the current increment
 * (This class is a singleton to ensure only one instance ever exists during runtime)
 */
public class ResultAccumulator implements ResultAccumulatorInterface{
    private LinkedList<PipelineResultSet> poaSortedResultSets; // (should be replaced by BinarySearchTree implementation)
    private ClustererInterface clusterer;

    public ResultAccumulator(ClustererInterface clusterer)
    {
        this.poaSortedResultSets = new LinkedList<PipelineResultSet>();
        this.clusterer = clusterer;
    }

    /**
     * Accumulates a pipeline resultset from a single message and inserts into ordered collection
     * @param resultSet
     */
    @Override
    public void accumulate(PipelineResultSet resultSet) {
        clusterer.insertToOrderedCollection(poaSortedResultSets, resultSet);
    }

    /**
     * Returns an ordered list of all accumulate resultsets thus far
     * @return Linked-List of all resultsets
     */
    @Override
    public LinkedList<PipelineResultSet> getOrderedResultSets() {
        return poaSortedResultSets;
    }

    /**
     * Clears the accumulated results in current increment for new increment
     */
    public void reset()
    {
        poaSortedResultSets.clear();
    }
}