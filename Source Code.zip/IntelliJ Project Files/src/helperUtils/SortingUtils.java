package helperUtils;

import interfaces.MessageInterface;

import java.util.Comparator;
import java.util.List;

/**
 * Provides sorting-related helper methods
 */
public abstract class SortingUtils {

    /**
     * Sorts a list of messages by timestamp in-place (mutates)
     * @param List of messages to sort
     */
    public static void sortMessagesByTime(List<MessageInterface> messages)
    {
         messages.sort(Comparator.comparing(message -> message.getTimeStamp()));
    }
}
