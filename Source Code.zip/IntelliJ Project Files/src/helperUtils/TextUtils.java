package helperUtils;

import models.Word;

import java.util.HashMap;
import java.util.List;

public abstract class TextUtils {

	/**
	 * Takes a string as input, and regardless of character case, returns the string with each word cvapitalized
	 * (String to lower case) --> (Capitalize each word)
	 * @param String input
	 * @return String with first character of each word capitalized
	 */
	public static String toFirstUpper(String str)
	{
		StringBuilder strBuilder = new StringBuilder();
		// split by words:
		String[] words = str.toLowerCase().split(" ");
		for(String word : words)
		{
			if(word.trim().length()>0)
			{
				strBuilder.append( Character.toUpperCase(word.charAt(0)) + word.substring(1) + " " );
			}
		}
	return strBuilder.toString().trim();	
	}

	/**
	 * Strips unsafe characters from string
	 * @param String to strip
	 * @return String with unsafe chars remoed
	 */
	public static String stripUnsafeChars(String str)
	{
		return str.replace("\"","")
				.replace("'","")
				.replace("\n","")
				.replace("\\","");
	}

	/**
	 * Recieves a list of words as input, and counts the occurance of each word
	 * @param words
	 * @return Hashmap where key is a given word, and value is number of occurances
	 */
	public static HashMap<String,Integer> countWordDistribution(List<Word> words)
	{
		HashMap<String,Integer> distributions = new HashMap<String,Integer>();

		for ( Word word : words)
		{
			if(distributions.get(word.getText())==null)
			{
				distributions.put(word.getText(),0);
			}
			distributions.put(word.getText(),distributions.get((word.getText()))+1);
		}
		return distributions;
	}

    /**
     * Converts a string-array to comma-separated string
     * @param arr
     * @return
     */
	public static String arrToString(String[] arr)
	{
		return String.join(",", arr);
	}

	/**
	 * Takes a list of words as input and returns the most commonly occuring word
	 * @param List of words
	 * @return Most commonly occuring word in list
	 */
	public static Word findMostCommonWord(List<Word> words)
	{
		// check empty list:
		if(words.size()<1)
		{
			return null;
		}
		// elect first element by default:
		HashMap<String,Integer> distribution = countWordDistribution(words);
		Word mostCommon=words.get(0);
		int mostCommonOccuranceCount=distribution.get(mostCommon.getText());
		for(Word word : words)
		{
			if(distribution.get(word.getText()) > mostCommonOccuranceCount)
			{
				mostCommon=word;
				mostCommonOccuranceCount=distribution.get(word.getText());
			}
		}
		return mostCommon;
	}
	
}
