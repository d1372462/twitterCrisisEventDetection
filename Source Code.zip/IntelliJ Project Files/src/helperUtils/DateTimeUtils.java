package helperUtils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Time and date related helper methods
 */
public class DateTimeUtils {

    /**
     * Returns a human-readable string of current date and time
     * @return Human-readable date & time
     */
    public static String getCurrentDateTime()
    {
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        return (dateFormat.format(date)); //2016/11/16 12:08:43
    }

    /**
     * Converts a numeric timestamp to string
     * @param timeStamp
     * @return
     */
    public static String timeStampToString(long timeStamp)
    {
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new java.util.Date((long)timeStamp*1000);
        return (dateFormat.format(date))+"T00:00:00";
    }
}
