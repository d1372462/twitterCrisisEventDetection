package helperUtils;

import java.util.Random;

/**
 * Helper methods to handle common number related tasks and checks
 */
public abstract class NumericUtils {
    /**
     * Checks if a string is (parsable) to a (long) number
     * @param String number to check
     * @return True/false is (natural) number
     */
    public static boolean checkStringIsNumber(String potentialNumber)
    {
        try{
            Long.parseLong(potentialNumber);
        }catch(Exception e)
        {
            return false;
        }
        return true;
    }

    /**
     * Generates a random numeric id
     * @return Random id
     */
    public static long generateId()
    {
        return new Random().nextLong();
    }

}
