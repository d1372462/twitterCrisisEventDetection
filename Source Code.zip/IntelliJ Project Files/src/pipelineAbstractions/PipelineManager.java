package pipelineAbstractions;

import analyzers.NaiveBayesClassifier;
import helperUtils.DateTimeUtils;
import interfaces.*;
import interfaces.ClassifierResultSetInterface;
import models.Cluster;
import models.Event;
import resultSets.ClassifierResultSet;
import resultSets.PlaceRecognizerResultSet;

import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Handles the incremental piping and clustering of messages to the pipeline
 * This class is responsible for feeding messages to the pipeline
 * until the increment size is reached, at which point it will initiate clustering,
 * and pass output to outputModules which will feed to the triplestore.
 */
public class PipelineManager {
    private ClusterPartitionerInterface clusterPartitioner;
    private EventExtractorInterface eventExtractor;
    private RelevanceAnalyzerInterface relevanceAnalyzer;
    private OutputCatcherInterface outputCatcher;
    private PlaceRecognizerInterface placeRecognizer;
    private LoggerInterface logger;
    private ResultAccumulatorInterface resultAccumulator;
    private PipelineInterface pipeline;
    private SentimentAnalyzerInterface sentimentAnalyzer;
    private ClassifierInterface sentimentClassifier;
    private long timeMin=-1;
    private int incrementSize;
    private double relevanceMinimum;
    private int spikeMinimum;

    /**
     *
     * @param resultAccumulator
     * @param outputCatcher
     * @param clusterer
     * @param clusterPartitioner
     * @param pipeline
     * @param logger
     * @param incrementSize
     * @param relevanceMinimum
     * @param spikeMinimum
     */
    public PipelineManager(
                           ResultAccumulatorInterface resultAccumulator,
                           OutputCatcherInterface outputCatcher,
                           ClusterPartitionerInterface clusterPartitioner,
                           PipelineInterface pipeline,
                           LoggerInterface logger,
                           EventExtractorInterface eventExtractor,
                           RelevanceAnalyzerInterface relevanceAnalyzer,
                           PlaceRecognizerInterface placeRecognizer,
                           SentimentAnalyzerInterface sentimentAnalyzer,
                           int incrementSize,
                           double relevanceMinimum,
                           int spikeMinimum
                           )
    {
        this.outputCatcher = outputCatcher;
        this.eventExtractor=eventExtractor;
        this.relevanceAnalyzer=relevanceAnalyzer;
        this.placeRecognizer=placeRecognizer;
        this.logger=logger;
        this.resultAccumulator=resultAccumulator;
        this.pipeline=pipeline;
        this.clusterPartitioner=clusterPartitioner;
        this.incrementSize=incrementSize;
        this.relevanceMinimum=relevanceMinimum;
        this.spikeMinimum=spikeMinimum;
        this.sentimentAnalyzer=sentimentAnalyzer;
    }

    private void logIncrement(int clusterCount, int disqualifiedCount)
    {
      logger.recieveText(
              "Increment at: "+
                DateTimeUtils.getCurrentDateTime()+System.lineSeparator() +
                " --- Stats ---- "+
                        System.lineSeparator() + "Clusters Found: "+clusterCount +
                        System.lineSeparator() + "Clusters disqualified: "+disqualifiedCount+
                        System.lineSeparator() + "Total kept: "+ (clusterCount - (disqualifiedCount))
      );
    }

    /**
     * Finalizes current increments and starts a new
     * (Does clustering, relevance checking, spike detection, and event extraction)
     * (passes resulting events to TriplestoreFeeder)
     */
    private void newIncrement()
    {
        // check for empty pos ordered list:
        if (resultAccumulator.getOrderedResultSets().size()<1)
        {
            // nothing to do in current increment.... return. (empty return justified)
            return;
        }
        int disqualifiedCount=0;
        int clustersFound=0;
        // partition sorted messages (by POS) to extract clusters:
        List<Cluster> clusters =clusterPartitioner.partitionOrderedList(
                resultAccumulator.getOrderedResultSets());
        clustersFound=clusters.size();
        // post-process clusters:
        clusters = clusters.stream()
        // keep only clusters that qualify in size:
                .filter(cluster -> cluster.size() >= spikeMinimum)
        // keep only clusters that qualify in relevance:
                .filter(cluster -> relevanceAnalyzer.analyze(cluster).getConfidence() >= relevanceMinimum)
                .collect(Collectors.toCollection(LinkedList::new));
        disqualifiedCount=clustersFound-clusters.size();
        // do place recognition and sentiment analysis:
        clusters.stream().forEach(
                cluster -> {
                    // do place recogniction:
                    PlaceRecognizerResultSet placeRecognizerResultSet =placeRecognizer.analyze(cluster);
                    cluster.setDetectedPlaces(placeRecognizerResultSet.getPlaces());
                    cluster.setMostLikelyPlace(placeRecognizerResultSet.getMostLikelyPlace());
                    // do sentiment analysis:
                    ClassifierResultSetInterface sentimentResults =
                    sentimentAnalyzer.analyze(cluster , new ClassifierResultSet());
                    // set results:
                    cluster.setSentiment(sentimentResults.getResultCategory());
                    cluster.setSentimentCondifdence(sentimentResults.getConfidence());
                }
        );
        // extract events from clusters:
        List<Event> events = eventExtractor.extractEvents(clusters);
        // feed to triplestore:
        outputCatcher.receiveEvents(events);
        // prep for new increment by clearing accumulated results from current increment:
        resultAccumulator.reset();
        // log increment:
        logIncrement(clustersFound,disqualifiedCount);
    }

    /**
     * Manages input for the pipieline. Receives messages adhereing to the streaming computational model, and manages when to count an increment and
     * perform clustering followed by extraction of events.
     * @param A message to send through
     */
    public void receiveMessage(MessageInterface message)
    {
        // set increment start time:
        if(timeMin < 0)
        {
            timeMin=message.getTimeStamp();
        }
        // check if increment time limit reached (time to start new increment):
        if ( (message.getTimeStamp()-timeMin) >= incrementSize)
        {
            // time to finalize current increment:
            timeMin = message.getTimeStamp();
            newIncrement();
        }
        // pass message through pipeline:
        pipeline.pipeThrough(message,resultAccumulator);
    }

    /**
     * Terminates current increment
     */
    private void terminateCurrentIncrement()
    {
        newIncrement();
    }

    /**
     * Performs post-stream operations once the PipelineManager is done
     * receiving a stream of messages
     */
    public void endOfStream()
    {
        terminateCurrentIncrement();
    }
}
