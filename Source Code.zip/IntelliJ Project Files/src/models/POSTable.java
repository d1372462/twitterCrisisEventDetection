package models;

import java.util.LinkedList;
import java.util.List;

public class POSTable {
    private List<Word> verbs;
    private List<Word> nouns;
    private List<Word> adjectives;
    private List<Word> properNouns;

    public POSTable()
    {
        this.verbs=new LinkedList<Word>();
        this.nouns=new LinkedList<Word>();
        this.adjectives=new LinkedList<Word>();
        this.properNouns=new LinkedList<Word>();
    }

    /**
     * Takes a POSTable as input and adds the verbs to (this) table
     * @param POSTable to merge with this table
     */
    public void merge(POSTable table)
    {
        this.adjectives.addAll(table.getAdjectives());
        this.verbs.addAll(table.getVerbs());
        this.nouns.addAll(table.getNouns());
        this.properNouns.addAll(table.getProperNouns());
    }

    public List<Word> getVerbs() {
        return verbs;
    }

    /**
     * Returns all POS tokenized words
     * in pos table
     * @return
     */
    public List<Word> getAll()
    {
        List<Word> allWords =new LinkedList<Word>();
        allWords.addAll(adjectives);
        allWords.addAll(verbs);
        allWords.addAll(properNouns);
        allWords.addAll(nouns);
        return allWords;
    }

    /**
     * Returns the total amount of words in the POSTable.
     * (getAll() is derived by combining multiple lists,
     * thus getAll().size() is too inefficient to use, and this is a more efficient
     * alternative to get word count)
     * @return Total amount of words in table
     */
    public int getSize()
    {
        return adjectives.size()+verbs.size()+properNouns.size()+nouns.size();
    }

    public void setVerbs(List<Word> verbs) {
        this.verbs = verbs;
    }

    public List<Word> getNouns() {
        return nouns;
    }

    public void setNouns(List<Word> nouns) {
        this.nouns = nouns;
    }

    public List<Word> getAdjectives() {
        return adjectives;
    }

    public void setAdjectives(List<Word> adjectives) {
        this.adjectives = adjectives;
    }

    public List<Word> getProperNouns() {
        return properNouns;
    }

    public void setProperNouns(List<Word> properNouns) {
        this.properNouns = properNouns;
    }

    public List<Word> getHashTags() {
        return hashTags;
    }

    public void setHashTags(List<Word> hashTags) {
        this.hashTags = hashTags;
    }

    private List<Word> hashTags;

}
