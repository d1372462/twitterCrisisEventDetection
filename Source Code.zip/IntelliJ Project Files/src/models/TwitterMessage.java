package models;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import interfaces.MessageInterface;

/**
 * Represents a TwitterMessage. 
 * (To be used as input for analyzers)
 * @author Daniel S. Valland
 *
 */
public class TwitterMessage implements MessageInterface{
private String text;
private long timeStamp;
private double eventConfidence;

	/**
	 * Constructor for TwitterMessage
	 * @param Text of TwitterMessage
	 */
	public TwitterMessage(String text)
	{
		this.text=text;
	}
	/**
	 * Constructor with no params for TwitterMessage
	 */
	public TwitterMessage()
	{
	}
	
	/* (non-Javadoc)
	 * @see interfaces.MessageInterface#getText()
	 */
	@Override
	public String getText() {
		return text;
	}
	

	/* (non-Javadoc)
	 * @see interfaces.MessageInterface#setText(java.lang.String)
	 */
	@Override
	public void setText(String text) {
		this.text=text;
	}

	@Override
	public long getTimeStamp() {
		return this.timeStamp;
	}

	@Override
	public void setTimeStamp(long timeStamp) {
		this.timeStamp=timeStamp;
	}

	@Override
	public String toString() {
	    return "Event confidence: "+this.eventConfidence+"\n\nMessage text: "+text;
	}
	
	
	

}
