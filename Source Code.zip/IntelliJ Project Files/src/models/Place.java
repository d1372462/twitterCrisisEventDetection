package models;

public class Place {
    private String URI;
    private String label;
    private String latd;
    private String longd;

    // GETTERS & SETTERS:
    public String getLatd() {
        return latd;
    }

    public void setLatd(String latd) {
        this.latd = latd;
    }

    public String getLongd() {
        return longd;
    }

    public void setLongd(String longd) {
        this.longd = longd;
    }

    /**
     * @return the uRI
     */
    public String getURI() {
        return URI;
    }
    /**
     * @param uRI the uRI to set
     */
    public void setURI(String uRI) {
        URI = uRI;
    }
    /**
     * @return the label
     */
    public String getLabel() {
        return label;
    }
    /**
     * @param label the label to set
     */
    public void setLabel(String label) {
        this.label = label;
    }
    @Override
    public String toString() {
        return this.URI;
    }
}