package models;

import java.util.List;

/**
 * Represents a given event
 * (to be used as output from event recognizer)
 *
 */
public class Event {
	// twitter message from which an event originates:
	private double sentimentCondifdence;
	private String sentiment;
	private double relevance;
	private String label;
	private String URI;
	private long timeStamp;
	private long id;
	private Cluster cluster;
	public List<String> tags;

    // GETTERS AND SETTERS:
    public List<String> getTags() {
        return tags;
    }

    public void setTags(List<String> tags) {
        this.tags = tags;
    }

    public long getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(long timeStamp) {
        this.timeStamp = timeStamp;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Cluster getCluster() {
        return cluster;
    }

    public void setCluster(Cluster cluster) {
        this.cluster = cluster;
    }

    /**

	 * @return the uRI
	 */
	public String getURI() {
		return URI;
	}

	/**
	 * @param uRI the uRI to set
	 */
	public void setURI(String URI) {
		this.URI = URI;
	}

    public double getSentimentCondifdence() {
        return sentimentCondifdence;
    }

    public void setSentimentCondifdence(double sentimentCondifdence) {
        this.sentimentCondifdence = sentimentCondifdence;
    }

    public String getSentiment() {
        return sentiment;
    }

    public void setSentiment(String sentiment) {
        this.sentiment = sentiment;
    }

    public double getRelevance() {
		return relevance;
	}

	public void setRelevance(double relevance) {
		this.relevance = relevance;
	}

	/**
	 * @return the label
	 */
	public String getLabel() {
		return label;
	}

	/**
	 * @param label the label to set
	 */
	public void setLabel(String label) {
		this.label = label;
	}

	/**
	 * Converts event instance to string
	 * @return Human-readable string representation of event
	 */
	@Override
	public String toString()
	{
		return "Label: "+label+System.lineSeparator()
                +"URI: "+URI+System.lineSeparator()
                +"Relevnce: "+getRelevance()+ System.lineSeparator()
				+"Sentiment: "+getSentiment()+System.lineSeparator()
                +"Sentiment Confidence: "+getSentimentCondifdence()+System.lineSeparator()
                +"Places: "+this.cluster.getDetectedPlaces() +System.lineSeparator()
                +"Most likely place: "+this.cluster.getMostLikelyPlace()+System.lineSeparator()
                +"Cluster size: "+this.cluster.size()+System.lineSeparator()
                +"Tags: "+tags.toString();
	}
}