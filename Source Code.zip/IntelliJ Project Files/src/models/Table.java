package models;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import interfaces.TableInterface;

/**
 * @author user
 *
 */
public class Table implements TableInterface{

	private List<HashMap<String,String>> table;
	private String[] tableSchema;
	
	/**
	 * Constructor for table
	 * @param tableSchema
	 */
	public Table(String[] tableSchema){
		this.table=new ArrayList<HashMap<String,String>>();
		this.tableSchema=tableSchema;
	}

	/* (non-Javadoc)
	 * @see interfaces.TableInterface#addRow(java.util.HashMap)
	 */
	@Override
	public void addRow(HashMap<String, String> row) {
		this.table.add(row);
	}

	@Override
	/**
	 * Adds a new row to the underlying table structure from String array.
	 * @param String array representing a table row
	 */
	public void addRow(String[] rowValues){
		HashMap<String,String> newRow = new HashMap<String,String>();
		for(int i=0; i < this.tableSchema.length; i++){ // for each column in schema, pair it with a value from rowValues array.
			newRow.put(this.tableSchema[i], rowValues[i]); // add values to row
		}
		this.table.add(newRow); // add row to list
	}

	/* (non-Javadoc)
	 * @see interfaces.TableInterface#getRow(int)
	 */
	@Override
	public HashMap<String, String> getRow(int rowIndex) {
		return table.get(rowIndex);
	}
	
	
	
	/**
	 * Returns the schema of the table as an array of strings.
	 * @return Schema array
	 */
	public String[] getTableSchema() {
		return tableSchema;
	}
	

	/* (non-Javadoc)
	 * @see interfaces.TableInterface#removeRow(int)
	 */
	@Override
	public void removeRow(int rowIndex) {
		// TODO Auto-generated method stub
		
	}
	
	/**
	 * Prints the table
	 */
	public void print()
	{
		System.out.println("Table Schema: " + Arrays.toString(this.tableSchema) + "\nNumber of rows: "+this.table.size());
		for(HashMap<String,String> row : this.table)
		{
			System.out.println();
			for (String col : this.getTableSchema())
			{
				if(row.get(col)==null)
				{
					System.out.print(" | NULL ");
				}else{
					System.out.print(" | "+row.get(col));
				}	
			}
			System.out.print(" |");
		}
		System.out.println();
		System.out.println();
	}

	@Override
	public List<HashMap<String, String>> getRows() {
		// TODO Auto-generated method stub
		return table;
	}

}
