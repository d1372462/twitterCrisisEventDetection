package models;

import resultSets.PipelineResultSet;

import java.util.LinkedList;
import java.util.List;

/**
 * Represents a cluster of several message resultsets that have common features (ex: POS overlap and location proximity etc...)
 */
public class Cluster
{
    private String label;
    private List<PipelineResultSet> resultSets;
    private POSTable accumulatedPOS;
    private List<Place> detectedPlaces;
    private Place mostLikelyPlace;
    private double sentimentCondifdence;
    private String sentiment;

    public Cluster()
    {
        this.resultSets=new LinkedList<PipelineResultSet>();
        this.accumulatedPOS=new POSTable();
    }
    // GETTERS AND SETTERS:
    public List<Place> getDetectedPlaces() {
        return detectedPlaces;
    }

    public void setDetectedPlaces(List<Place> detectedPlaces) {
        this.detectedPlaces = detectedPlaces;
    }

    public void setAccumulatedPOS(POSTable accumulatedPOS) {
        this.accumulatedPOS = accumulatedPOS;
    }

    public Place getMostLikelyPlace() {
        return mostLikelyPlace;
    }

    public void setMostLikelyPlace(Place mostLikelyPlace) {
        this.mostLikelyPlace = mostLikelyPlace;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public List<PipelineResultSet> getResultSets() {
        return resultSets;
    }

    public void setResultSets(List<PipelineResultSet> resultSets) {
        this.resultSets = resultSets;
    }

    public double getSentimentCondifdence() {
        return sentimentCondifdence;
    }

    public void setSentimentCondifdence(double sentimentCondifdence) {
        this.sentimentCondifdence = sentimentCondifdence;
    }

    public String getSentiment() {
        return sentiment;
    }

    public void setSentiment(String sentiment) {
        this.sentiment = sentiment;
    }

    public POSTable getAccumulatedPOS() {
        return accumulatedPOS;
    }

    public void add(PipelineResultSet resultSet)
    {
        this.resultSets.add(resultSet);
        this.accumulatedPOS.merge(resultSet.getPoaResults().getPosTable());
    }

    /**
     * Returns size of cluster (amount of messages in cluster)
     * @return Size of cluster
     */
    public int size()
    {
        return this.getResultSets().size();
    }

    @Override
    public String toString(){
    StringBuilder out = new StringBuilder();
    resultSets.stream().forEach( res -> out.append(res.getOriginMessage().getText()+System.lineSeparator()));
    return out.toString()+"---------------------"+System.lineSeparator();
    }
}
