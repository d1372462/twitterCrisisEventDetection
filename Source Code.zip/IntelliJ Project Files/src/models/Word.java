package models;

public class Word {

	private double confidence;
	private String text;
	private String wordType;

	public Word(String text) {
		this.text = text;
	}

	public Word() {

	}
	/**
	 * @return the confidence
	 */
	public double getConfidence() {
		return confidence;
	}
	/**
	 * @param confidence the confidence to set
	 */
	public void setConfidence(double confidence) {
		this.confidence = confidence;
	}
	/**
	 * @return the text
	 */
	public String getText() {
		return text;
	}
	/**
	 * @param text the text to set
	 */
	public void setText(String text) {
		this.text = text;
	}
	/**
	 * @return the wordType
	 */
	public String getWordType() {
		return wordType;
	}
	/**
	 * @param wordType the wordType to set
	 */
	public void setWordType(String wordType) {
		this.wordType = wordType;
	}

	@Override
	public String toString() {
		return this.text;
	}

	@Override
	public boolean equals(Object object) {
		// check that both are instance of word, and have the same tet and word type (case-insensitive):
		return (object instanceof Word) && ((Word) object).getText().toLowerCase().equals(getText().toLowerCase()) && ((Word) object).getWordType().toLowerCase().equals(getWordType().toLowerCase());
	}

	@Override
	public int hashCode() {
		return (getText().toLowerCase() + getWordType().toLowerCase()).hashCode();
	}
}