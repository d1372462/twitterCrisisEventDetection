package dataSources;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

public class XPathParser {

    /**
     * Performs a given XPath Query on the given xml file
     * @param XPATH Query
     * @param XML File path
     * @return NodeList of found nodes
     */
    public NodeList query(String xpathQuery, String xmlFilePath)
    {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

        try {
            DocumentBuilder builder= factory.newDocumentBuilder();
            // parse xml:
            Document doc = builder.parse(xmlFilePath);
            XPathFactory xPathfactory = XPathFactory.newInstance();
            XPath xpath = xPathfactory.newXPath();
            // compile xpath query:
            XPathExpression expr = xpath.compile(xpathQuery);
            // run query and return resulting nodeList:
            return (NodeList) expr.evaluate(doc, XPathConstants.NODESET);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }
}
