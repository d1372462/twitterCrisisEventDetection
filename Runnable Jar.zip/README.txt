This is a runable jar for testing / example purposes. It is set to a spike minimu of 1 ( cluster minimum is 1), meaning that each event only needs 1 supporting twitter message to be detected as
an event.  The spike minimum can be arbitrary defined in the code, and would normally be set much higher, but this is good for testing purposes.

example.xml contains a small set of 11 test messages talking about several different events.  

Running the test example:

use the command: java -jar tct.jar example.xml

to run the example.
